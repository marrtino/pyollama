# File: rag_chain.py
# Descrizione: Gestione dell'ingestione di PDF e interrogazione tramite RAG con LangChain e Ollama

from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.llms import Ollama
from langchain.chains import RetrievalQA

import os
import shutil

PDF_DIR = 'data/pdfs'
VECTOR_DIR = 'data/vectors'
os.makedirs(VECTOR_DIR, exist_ok=True)

embedding = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')

# Funzione per caricare il vectorstore da file se esiste
def load_vectorstore():
    faiss_index = os.path.join(VECTOR_DIR, 'index.faiss')
    if os.path.exists(faiss_index):
        print("[INFO] Caricamento vectorstore FAISS esistente...")
        return FAISS.load_local(VECTOR_DIR, embeddings=embedding, allow_dangerous_deserialization=True)
    else:
        print("[INFO] Nessun vectorstore FAISS trovato.")
        return None

vectorstore = load_vectorstore()

def ingest_pdfs(pdf_paths):
    global vectorstore
    all_chunks = []
    for pdf_path in pdf_paths:
        print(f"[INFO] Caricamento PDF: {pdf_path}")
        loader = PyPDFLoader(pdf_path)
        documents = loader.load()
        print(f"[INFO] Trovate {len(documents)} pagine in {pdf_path}")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        chunks = text_splitter.split_documents(documents)
        print(f"[INFO] Generati {len(chunks)} frammenti da indicizzare.")
        all_chunks.extend(chunks)

    if vectorstore is None:
        vectorstore = FAISS.from_documents(all_chunks, embedding)
    else:
        vectorstore.add_documents(all_chunks)

    vectorstore.save_local(VECTOR_DIR)
    return len(all_chunks), all_chunks  # Restituisce anche i chunk per l'esplorazione



def ask_question(question, model_name='mistral', system_message=None):
    if vectorstore is None:
        return "[ERRORE] Nessun documento indicizzato. Caricare un PDF."

    from langchain_community.llms import Ollama
    from langchain_core.prompts import ChatPromptTemplate
    from langchain.chains import RetrievalQA

    llm = Ollama(model=model_name)

    retriever = vectorstore.as_retriever()
    system_message = "Rispondi solo in italiano"
    if system_message:
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_message),
            ("human", "{question}")
        ])
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            chain_type_kwargs={"prompt": prompt}
        )
        print (system_message)
    else:
        qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
        print ("no system message")

    return qa_chain.run(question)


def get_indexed_chunks():
    if vectorstore is None:
        return []
    docs = vectorstore.similarity_search("*", k=50)
    return [doc.page_content for doc in docs]

# Funzione per eliminare tutti i chunk indicizzati (reset index)
def clear_vectorstore():
    global vectorstore
    if os.path.exists(VECTOR_DIR):
        shutil.rmtree(VECTOR_DIR)
        os.makedirs(VECTOR_DIR, exist_ok=True)
    vectorstore = None
    print("[INFO] Vectorstore eliminato.")
